popsim <-
function(N,n,N.gen,N.markers,pop,apa=0.5,apb=0.5){

N.chrom = 2*N # number of chromosomes
p<-rbeta(N.markers,apa,apb)
q = 1-p
N.gen
N.markers

result<-list()
for (z in 1:pop){
# Simulation
X = array(0, dim=c(N.gen,N.markers))
X[1,] = N.chrom*p # initialize number of A alleles (dominant) in first generation
for(j in 1:N.markers){
  for(i in 2:N.gen){
    X[i,j] = rbinom(1,N.chrom,prob=X[i-1,j]/N.chrom)
    }  
  }
X = data.frame(X/N.chrom)
p.t<-X[N.gen,]
p.t<-as.numeric(p.t)
#Tranform allelic frequency to phenotypic frequency
p1<-p.t*(2-p.t)
#Data
mat<-matrix( 1,N,N.markers)
for (i in 1:N.markers)
mat[,i]<-rbinom(N,1,p1[i])
markers<-paste("M",seq(1,N.markers,1),sep="")
ind<-paste("ind",seq(1,N,1),sep="")
colnames(mat)<-markers
rownames(mat)<-ind
mat
mat<-mat[sample(nrow(mat), N), ]
sub<-sort(paste("subsubpop",rep(1:n,N/n),sep=""))
newpas<-as.data.frame(cbind(sub,mat))
dat<-split(newpas,newpas$sub)
result[[z]]<-dat
}
popnames<-paste("subpopulation",seq(1,pop,1),sep="")
names(result)<-popnames
result
}
